#!/usr/bin/env python3
"""국토부 아파트 전월세 실거래 API에서 관심 단지의 전세 거래를 가져와 data/trades.json에 누적 저장."""
import json, os, sys, time
import urllib.parse, urllib.request
import xml.etree.ElementTree as ET
from datetime import date, datetime, timezone, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CFG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
OUT = ROOT / "data" / "trades.json"
URL = "https://apis.data.go.kr/1613000/RTMSDataSvcAptRent/getRTMSDataSvcAptRent"
# 인코딩 키/디코딩 키 어느 쪽을 넣어도 동작하게 한 번 풀어서 사용
KEY = urllib.parse.unquote(os.environ.get("DATA_GO_KR_KEY", "").strip())
MONTHS = int(os.environ.get("MONTHS") or 3)
KST = timezone(timedelta(hours=9))


def norm(s):
    return "".join((s or "").split()).lower()


def months_back(n):
    t = datetime.now(KST).date()
    y, m = t.year, t.month
    out = []
    for _ in range(n):
        out.append(f"{y}{m:02d}")
        m -= 1
        if m == 0:
            y, m = y - 1, 12
    return out


def txt(item, *tags):
    for t in tags:
        e = item.find(t)
        if e is not None and e.text and e.text.strip():
            return e.text.strip()
    return ""


def fetch(lawd, ymd):
    items, page = [], 1
    while True:
        q = urllib.parse.urlencode({
            "serviceKey": KEY, "LAWD_CD": lawd, "DEAL_YMD": ymd,
            "pageNo": page, "numOfRows": 1000,
        })
        root = None
        for attempt in range(3):
            try:
                with urllib.request.urlopen(f"{URL}?{q}", timeout=30) as r:
                    root = ET.fromstring(r.read())
                break
            except Exception as e:
                print(f"  재시도 {attempt+1}/3 ({lawd} {ymd}): {e}")
                time.sleep(2)
        if root is None:
            return None
        code = (root.findtext(".//resultCode") or "").strip()
        if code not in ("00", "000"):
            print(f"  API 오류 {lawd} {ymd}: {code} {root.findtext('.//resultMsg')}")
            return None
        got = root.findall(".//item")
        items += got
        total = int(root.findtext(".//totalCount") or 0)
        if len(items) >= total or not got:
            return items
        page += 1


def parse(it):
    try:
        rent = int((txt(it, "monthlyRent", "월세금액") or "0").replace(",", ""))
        dep = int(txt(it, "deposit", "보증금액").replace(",", ""))
        area = float(txt(it, "excluUseAr", "전용면적"))
        y = int(txt(it, "dealYear", "년")); m = int(txt(it, "dealMonth", "월")); d = int(txt(it, "dealDay", "일"))
    except ValueError:
        return None
    fl = txt(it, "floor", "층")
    return {
        "apt": txt(it, "aptNm", "아파트"), "umd": txt(it, "umdNm", "법정동"),
        "rent": rent, "p": dep, "a": round(area, 1), "d": f"{y:04d}-{m:02d}-{d:02d}",
        "f": int(fl) if fl.lstrip("-").isdigit() else None,
        "t": txt(it, "contractType", "계약구분"),
    }


def main():
    if not KEY:
        sys.exit("DATA_GO_KR_KEY 가 설정되지 않았어요 (GitHub Secrets 확인).")
    needed = sorted({(l, ym) for c in CFG["complexes"] for l in c["lawd"] for ym in months_back(MONTHS)})
    cache, ok = {}, 0
    for lawd, ym in needed:
        res = fetch(lawd, ym)
        if res is not None:
            ok += 1
            cache[(lawd, ym)] = [p for p in map(parse, res) if p]
        time.sleep(0.3)
    if ok == 0:
        sys.exit("모든 API 호출이 실패했어요. 인증키/활용신청 승인 상태를 확인하세요.")

    old = json.loads(OUT.read_text(encoding="utf-8")) if OUT.exists() else {"trades": []}
    seen = {}
    for t in old.get("trades", []):
        seen[(t["c"], t["d"], t["a"], t["f"], t["p"])] = t
    today = datetime.now(KST).date().isoformat()
    added = 0

    for c in CFG["complexes"]:
        aliases = [norm(a) for a in c["aliases"]]
        matched, names = 0, set()
        for (lawd, ym), rows in cache.items():
            if lawd not in c["lawd"]:
                continue
            for r in rows:
                if c["umd"] and r["umd"] not in c["umd"]:
                    continue
                names.add(r["apt"])
                if r["rent"] != 0 or not (CFG["min_area"] <= r["a"] <= CFG["max_area"]):
                    continue
                if not any(a in norm(r["apt"]) for a in aliases):
                    continue
                matched += 1
                k = (c["id"], r["d"], r["a"], r["f"], r["p"])
                if k not in seen:
                    seen[k] = {"c": c["id"], "d": r["d"], "a": r["a"], "f": r["f"], "p": r["p"], "t": r["t"], "s": today}
                    added += 1
        print(f"{c['name']}: 조회된 전세 {matched}건")
        if matched == 0:
            print(f"  ⚠ 일치하는 거래 없음. 해당 지역 단지명 예시: {sorted(names)[:30]}")
            print("  → config.json 의 aliases/umd/lawd 를 위 이름에 맞게 고쳐 주세요.")

    trades = sorted(seen.values(), key=lambda t: (t["d"], t["c"]), reverse=True)
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text(json.dumps({
        "updated": datetime.now(KST).isoformat(timespec="minutes"),
        "complexes": [{"id": c["id"], "name": c["name"]} for c in CFG["complexes"]],
        "trades": trades,
    }, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"완료: 신규 {added}건 추가, 총 {len(trades)}건")


if __name__ == "__main__":
    main()
